#!/usr/bin/env python3
import brain_games.games.calc as game
import brain_games.func


def main():
    brain_games.func.play(game)


if __name__ == '__main__':
    main()
