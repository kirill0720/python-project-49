### Hexlet tests and linter status:
[![Actions Status](https://github.com/kirill0720/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/kirill0720/python-project-49/actions)

### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/0b89d4ad29da6181d3fb/maintainability)](https://codeclimate.com/github/kirill0720/python-project-49/maintainability)

[Terminal session record](https://asciinema.org/a/525854)
