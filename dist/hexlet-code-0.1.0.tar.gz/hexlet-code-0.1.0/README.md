### Hexlet tests and linter status:
[![Actions Status](https://github.com/kirill0720/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/kirill0720/python-project-49/actions)

### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/0b89d4ad29da6181d3fb/maintainability)](https://codeclimate.com/github/kirill0720/python-project-49/maintainability)

### brain-even
[Terminal session record](https://asciinema.org/a/525854)

### brain-calc
[Terminal session record](https://asciinema.org/a/525907)

### brain-gcd
[Terminal session record](https://asciinema.org/a/525921)

### brain-progression
[Terminal session record](https://asciinema.org/a/525931)

### brain-prime
[Terminal session record](https://asciinema.org/a/525934)
